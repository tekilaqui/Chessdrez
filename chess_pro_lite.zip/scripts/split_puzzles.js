const fs = require('fs');
const path = require('path');

const puzzlesPath = path.join(__dirname, '../puzzles_data.js');
console.log('Reading puzzles from:', puzzlesPath);

try {
    let content = fs.readFileSync(puzzlesPath, 'utf8');

    // Strip variable declaration
    content = content.replace('const LOCAL_PUZZLES_DB = ', '').trim();
    if (content.endsWith(';')) {
        content = content.slice(0, -1);
    }

    const puzzles = JSON.parse(content);
    console.log(`Loaded ${puzzles.length} puzzles.`);

    const grouped = {};

    puzzles.forEach(puzzle => {
        const themes = puzzle.Themes || 'mix';
        // Limpiamos caracteres extraños y usamos la primera palabra como categoría
        const category = themes.split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
        const rating = parseInt(puzzle.Rating);
        const range = Math.floor(rating / 400) * 400;
        const key = `${category}_${range}`;

        if (!grouped[key]) grouped[key] = [];

        grouped[key].push({
            id: puzzle.PuzzleId,
            fen: puzzle.FEN,
            solution: puzzle.Moves.split(' '),
            rating: puzzle.Rating,
            themes: puzzle.Themes,
            category: category
        });
    });

    Object.keys(grouped).forEach(key => {
        const [category, minRating] = key.split('_');
        const maxRating = parseInt(minRating) + 400;
        const dir = path.join(__dirname, `../data/puzzles/${category}`);

        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        const filename = path.join(dir, `${minRating}-${maxRating}.json`);
        fs.writeFileSync(filename, JSON.stringify(grouped[key], null, 2));
        console.log(`Created: ${filename} (${grouped[key].length} puzzles)`);
    });

    // Create manifest index
    const manifest = {
        categories: Object.keys(grouped).reduce((acc, key) => {
            const [cat] = key.split('_');
            if (!acc[cat]) acc[cat] = { count: 0, files: [] };
            acc[cat].count += grouped[key].length;
            acc[cat].files.push(key);
            return acc;
        }, {}),
        generatedAt: new Date().toISOString()
    };

    fs.writeFileSync(
        path.join(__dirname, '../data/puzzles/index.json'),
        JSON.stringify(manifest, null, 2)
    );

    console.log('Done splitting puzzles.');

} catch (err) {
    console.error('Error processing puzzles:', err);
}
