require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();
const USERS_PATH = path.join(__dirname, '../users.json');

async function migrate() {
    try {
        if (!fs.existsSync(USERS_PATH)) {
            console.log('No users.json found, skipping migration.');
            return;
        }

        const usersData = JSON.parse(fs.readFileSync(USERS_PATH, 'utf8'));
        const usernames = Object.keys(usersData);

        for (const username of usernames) {
            const data = usersData[username];
            console.log(`Migrating user: ${username}`);

            await prisma.user.upsert({
                where: { username },
                update: {},
                create: {
                    username: username,
                    email: data.email || `${username}@example.com`,
                    hash: data.hash,
                    salt: data.salt,
                    elo: data.elo || 500,
                    puzElo: data.puzElo || 500,
                    createdAt: new Date(data.createdAt || Date.now()),
                    wins: data.stats?.wins || 0,
                    losses: data.stats?.losses || 0,
                    draws: data.stats?.draws || 0
                }
            });
        }

        console.log('Migration completed successfully!');
    } catch (error) {
        console.error('Error during migration:', error);
    } finally {
        await prisma.$disconnect();
    }
}

migrate();
